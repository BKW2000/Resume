# CV and Cover Letter
CV and Cover Letter provided on 3/6/24 of a position in the Department of Operations and Business Anaylytics at OSU.  See:  https://osu.wd1.myworkdayjobs.com/en-US/OSUCareers/login
